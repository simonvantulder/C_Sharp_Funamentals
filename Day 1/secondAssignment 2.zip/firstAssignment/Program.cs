﻿using System;
using System.Collections.Generic;

namespace firstAssignment
{
    class Program
    {
        static void Main(string[] args){
            int[] arr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
            string[] myCars = new string[] { "Tim", "Ford Model T", "Martin", "Diamontra"};
            Boolean[] myBoolean = new Boolean[10];
            for( int i = 0; i < 10; i= i+2 ){
                myBoolean[i]= true;
                myBoolean[i+1]= false;
            }
            List<string> icecreamFlavors = new List<string>();
            icecreamFlavors.Add("homemade Vanilla");
            icecreamFlavors.Add("Lopez Island Creamery Vanilla");
            icecreamFlavors.Add("PCC Vanilla");
            icecreamFlavors.Add("TJs Vanilla");
            icecreamFlavors.Add("Raspberry");
            icecreamFlavors.Add("cookies & cream");
            Console.WriteLine($"We currently have {icecreamFlavors.Count} flavors of icecream");
            icecreamFlavors.Remove("TJs Vanilla");
            Console.WriteLine($"We currently have {icecreamFlavors.Count} flavors of icecream");

            // Dictionary<string,string> bikes = new Dictionary<string,string>();
            // bikes.Add("Brand", "sevencycles");
            // bikes.Add("weight", "12lbs");
            // bikes.Add("material", "titanium");
            // bikes.Add("type", "road");

            Dictionary<string,string> users = new Dictionary<string,string>();
            for (int i = 0; i < myCars.Length; i++){
            users.Add("Name" + i, $"{myCars[i]}");
            users.Add("icecream" + i, $"{icecreamFlavors[i]}");
            }
            foreach(KeyValuePair <string,string> entry in users){
                Console.WriteLine(entry.Key + "" + entry.Value);
            }



        }
    }
}
