﻿using System;

namespace firstAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            while(i < 256){
                Console.WriteLine(i);
                i++;
            }

            int j = 1;
            while(j < 100){

                if( j % 5 == 0 && j % 3 != 0|| j % 5 != 0 && j % 3 == 0 ){
                Console.WriteLine(j);
                j++;
                }
            else j++;
            }
            int k = 1;
            while(k < 100){
                if( j % 5 == 0 && j % 3 == 0){
                    Console.WriteLine("GoZoomZoom");
                    k++;
                }
                else if( k % 5 == 0 ){
                    Console.WriteLine("zoomzoom");
                    k++;
                } 
                else if (k % 3 == 0){
                    Console.WriteLine("zoom");
                    k++;
                }
                else {
                    k++;
                }
            }
        }
    }
}
