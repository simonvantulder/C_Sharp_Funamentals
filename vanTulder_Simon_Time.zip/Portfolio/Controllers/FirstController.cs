using Microsoft.AspNetCore.Mvc;
using System;

namespace Portfolio.Controllers
{
    public class FirstController : Controller 
    {
        [HttpGet("")]
        public ViewResult Time()
        {
            // will attempt to serve 
                // Views/Hello/Index.cshtml
            // or if that file isn't there:
                // Views/Shared/Index.cshtml
            DateTime CurrentDate = DateTime.Now;
            DateTime CurrentMilitaryTime = DateTime.Now;
            DateTime CurrentTime = DateTime.Now;

            string Date = CurrentDate.ToString("MMMM dd, yyyy");
            string MilitaryTime = CurrentMilitaryTime.ToString("HH:mm");
            string Time = CurrentTime.ToString("hh:mm tt");

            ViewBag.Date = Date;
            ViewBag.MilitaryTime = MilitaryTime;
            ViewBag.Time = Time;

            return View();
        }
        [HttpGet("home")]
        public ViewResult Index()
        {
            // will attempt to serve 
                // Views/Hello/Index.cshtml
            // or if that file isn't there:
                // Views/Shared/Index.cshtml
            ViewBag.Example = "Hello World!";

            return View();
        }
        [HttpGet]
        [Route("contact")]
        public ViewResult Contact()
        {
            // Same logic for serving a view applies
            // if we provide the exact view name
            return View("Contact");
        }
        // You may also serve the same view twice from additional actions
        [HttpGet("projects")]
        public ViewResult Projects()
        {
            // This would be a case where we have to specify the file name
            return View("Projects");
        }
    }
}