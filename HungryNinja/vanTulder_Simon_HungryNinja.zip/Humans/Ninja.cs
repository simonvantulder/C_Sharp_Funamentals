using System;
using System.Collections.Generic;


namespace Humans{
    class Ninja
{
    private int calorieIntake;
    // private Boolean IsFull;
    public List<Food> FoodHistory;
     

     public Ninja(){
        calorieIntake = 0;
        FoodHistory = new List<Food>();
    }
    // add a public "getter" property called "IsFull"
     public Boolean isFull
    {
        get { if (this.calorieIntake >= 1200) return true; else return false; }
    }
    // build out the Eat method
    public void Eat(Food item)
    {
        if( this.isFull){
            Console.WriteLine( "This Ninja is Full and can't eat anymore.");
        }
        else { 
            // while ( !this.isFull){

            calorieIntake += item.Calories;
            FoodHistory.Add(item);
            Console.WriteLine($"{item.Name} + {item.IsSweet}");
            // }

        }
    }

}

}