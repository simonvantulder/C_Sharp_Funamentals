using System;
using System.Collections.Generic;


namespace HungryNinja
{

    abstract class Ninja
{
    protected int calorieIntake;
    public List<IConsumable> ConsumptionHistory;
    public Ninja()
    {
        calorieIntake = 0;
        ConsumptionHistory = new List<IConsumable>();
    }
    public abstract bool IsFull {get;}
    public abstract void Consume(IConsumable item);
}


    // private int calorieIntake;
    // private Boolean IsFull;
     

    // add a public "getter" property called "IsFull"
//      public Boolean isFull
//     {
//         get { if (this.calorieIntake >= 1200) return true; else return false; }
//     }
    // build out the Eat method



    // public void Eat(Food item)
    // {
    //     if( this.isFull){
    //         Console.WriteLine( "This Ninja is Full and can't eat anymore.");
    //     }
    //     else { 
    //         // while ( !this.isFull){

    //         calorieIntake += item.Calories;
    //         FoodHistory.Add(item);
    //         Console.WriteLine($"{item.Name} + {item.IsSweet}");
    //         // }

    //     }
    // }

}

