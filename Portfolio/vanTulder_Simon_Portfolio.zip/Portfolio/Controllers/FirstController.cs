using Microsoft.AspNetCore.Mvc;
namespace Portfolio.Controllers
{
    public class FirstController : Controller 
    {
        [HttpGet("")]
        public string Index()
        {
            return $"This is my index page you Chump!";
        }

        
        [HttpGet("projects")]
        public string projects()
        {
            return $"This is my project page you Chump!";
        }

        
        [HttpGet("contact")]
        public string contact()
        {
            return $"This is my contact page you Chump!";
        }
    }
}