using System;
namespace Phone
{
public class Google : Phone, IRingable 
{
    public Google(string versionNumber, int batteryPercentage, string carrier, string ringTone) 
        : base(versionNumber, batteryPercentage, carrier, ringTone) {}
    public string Ring(Google pixel) 
    {
        // your code here
        return $"Your Google Pixel is Ringing: {pixel.ringTone}";
    }
    public string Unlock() 
    {
        return "Unlocked your Google Pixel";
    }


        public override void DisplayInfo()
        {
        // your code here
        Console.WriteLine($"You have a Google {this.versionNumber}, your phone is {this.batteryPercentage}% charged, you use {this.carrier}, youre ringtone is {this.ringtone}")
        }
    }
    
}