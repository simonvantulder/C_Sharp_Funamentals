namespace Phone
{
public class Nokia : Phone, IRingable 
{
    public Nokia(string versionNumber, int batteryPercentage, string carrier, string ringTone) 
        : base(versionNumber, batteryPercentage, carrier, ringTone) {}
    public string Ring() 
    {
        // your code here
        return " Nokia Ring Ring";
    }
    public string Unlock() 
    {
        // your code here
        return "Unlocked your Nokia Note with creepy facial recognition that you shouldnt use";
    }
    public override void DisplayInfo() 
    {
        Console.WriteLine($"you haev a Nokia {this.versionNumber}, your phone is {this.batteryPercentage}% charged, you use {this.carrier}, youre ringtone is {this.ringtone}")
    }
}
    
}