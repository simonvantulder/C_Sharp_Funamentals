﻿using System;

namespace Humans
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("!");
        }
    }
}
